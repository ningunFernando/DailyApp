import 'package:flutter/material.dart';
import 'package:daily_app/screens/navigation_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/custom_text_field.dart';
import './register_screen.dart';
import '../services/api_service.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final ApiService apiService = ApiService();

  void _login() async {
    String correo = _emailController.text;
    String contrasena = _passwordController.text;

    final response = await apiService.loginUser(correo, contrasena);

    if (response['status'] == 'success') {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isLoggedIn', true);
      await prefs.setInt('userId', response['usuario']['id']);
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => NavigationScreen()),
      );
    }else if(response['status'] == 'error'){

    }
    else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(response['message'])),
      );
    }
  }

  void MovePage() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => RegisterScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).primaryColor;
    final secondaryColor = Theme.of(context).secondaryHeaderColor;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Dai.ly',
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.w700,
            fontFamily: 'Poppins',
          ),
        ),
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 30),
        child: ListView(
          children: [
            Image.asset('images/IconoApp.png', scale: 2),
            CustomTextField(
              controller: _emailController,
              keyboardType: TextInputType.text,
              labelText: 'Correo',
              prefixIcon: Icons.account_circle_outlined,
            ),
            SizedBox(height: 20),
            CustomTextField(
              controller: _passwordController,
              keyboardType: TextInputType.text,
              labelText: 'Contraseña',
              isPassword: true,
              prefixIcon: Icons.lock_outline,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryColor,
              ),
              onPressed: _login,
              child: Text(
                'Iniciar sesión',
                style: TextStyle(color: secondaryColor),
              ),
            ),
            Text(
              'No tienes cuenta?',
              style: TextStyle(color: Colors.grey.shade500),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: secondaryColor,
              ),
              onPressed: MovePage,
              child: Text('Registrate'),
            ),
          ],
        ),
      ),
    );
  }
}
