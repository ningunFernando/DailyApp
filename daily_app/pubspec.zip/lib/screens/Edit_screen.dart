import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';

class EditUserScreen extends StatefulWidget {
  @override
  _EditUserScreenState createState() => _EditUserScreenState();
}

class _EditUserScreenState extends State<EditUserScreen> {
  final _nameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final ApiService apiService = ApiService();
  int userId = 0;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      userId = prefs.getInt('userId') ?? 0;
      _nameController.text = prefs.getString('Name') ?? '';
      _lastNameController.text = prefs.getString('Lastname') ?? '';
      _emailController.text = prefs.getString('email') ?? '';
      _phoneController.text = prefs.getString('phone') ?? '';
    });
  }

  Future<void> _editProfile() async {
    final response = await apiService.editProfile(
      userId,
      _nameController.text,
      _lastNameController.text,
      _emailController.text,
      _phoneController.text,
    );

    if (response['status'] == 'success') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Perfil actualizado exitosamente')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(response['message'])),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Editar Perfil')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _nameController, decoration: InputDecoration(labelText: 'Nombre')),
            TextField(controller: _lastNameController, decoration: InputDecoration(labelText: 'Apellido')),
            TextField(controller: _emailController, decoration: InputDecoration(labelText: 'Correo')),
            TextField(controller: _phoneController, decoration: InputDecoration(labelText: 'Teléfono')),
            ElevatedButton(
              onPressed: _editProfile,
              child: Text('Guardar Cambios'),
            ),
          ],
        ),
      ),
    );
  }
}
