import 'package:daily_app/screens/Edit_screen.dart';
import 'package:daily_app/screens/login_screen.dart';
import 'package:daily_app/widgets/profile_pickture.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear(); // Limpiar el estado de sesión

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => LoginScreen()),
    );
  }

  void MoveEdit() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => EditUserScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Perfil de Usuario',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            fontFamily: 'Poppins',
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: _logout, // Botón de cierre de sesión
          ),
        ],
      ),
      body: Center(
        child: Column(
          children: [
            ProfileImageSelector(), // Widget para la imagen de perfil
            ElevatedButton(
              onPressed: MoveEdit,
              child: Text('Editar Perfil'),
            ),
          ],
        ),
      ),
    );
  }
}
