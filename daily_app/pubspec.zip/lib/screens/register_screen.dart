import 'package:flutter/material.dart';
import '../widgets/custom_text_field.dart';
import 'package:shared_preferences/shared_preferences.dart';
import './navigation_screen.dart';
import '../services/api_service.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _nameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _confirmEmailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final ApiService apiService = ApiService();

  void _register() async {
    String name = _nameController.text;
    String lastName = _lastNameController.text;
    String email = _emailController.text;
    String confirmEmail = _confirmEmailController.text;
    String password = _passwordController.text;
    String confirmPassword = _confirmPasswordController.text;
    String phone = _phoneController.text;

    if (email != confirmEmail || password != confirmPassword) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Los datos no coinciden')),
      );
      return;
    }

    final response = await apiService.registerUser(name, lastName, email, password, phone);

    // Imprimir la respuesta para depuración
    print("Respuesta del servidor: $response");

    if (response['status'] == 'success') {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isLoggedIn', true);
      await prefs.setInt('userId', int.parse(response['id']));


      print("Registro exitoso. Navegando a NavigationScreen...");
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => NavigationScreen()),
      );
    } else {
    ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(response['message'])),
    );
    }
  }

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).primaryColor;
    final secondaryColor = Theme.of(context).secondaryHeaderColor;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Dai.ly',
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.w700,
            fontFamily: 'Poppins',
          ),
        ),
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 30),
        child: ListView(
          children: [
            Image.asset('images/IconoApp.png', scale: 4,),
            CustomTextField(
              labelText: ('Correo'),
              prefixIcon: Icons.email_outlined,
              controller: _emailController,
            ),
            CustomTextField(
              labelText: ('Confirmar Correo'),
              prefixIcon: Icons.email_outlined,
              controller: _confirmEmailController,
            ),
            CustomTextField(
              labelText: ('Contraseña'),
              prefixIcon: Icons.lock_outline,
              controller: _passwordController,
              isPassword: true,
            ),
            CustomTextField(
              labelText: ('Confirmar Contraseña'),
              prefixIcon: Icons.lock_outline,
              controller: _confirmPasswordController,
              isPassword: true,
            ),
            CustomTextField(
              labelText: ('Nombre'),
              prefixIcon: Icons.account_circle_outlined,
              controller: _nameController,
            ),
            CustomTextField(
              labelText: ('Apellido'),
              prefixIcon:  Icons.account_circle_outlined,
              controller: _lastNameController,
            ),
            CustomTextField(
              keyboardType: TextInputType.numberWithOptions(),
              labelText: ('Telefono'),
              prefixIcon: Icons.phone_android_outlined,
              controller: _phoneController,
            ),
            SizedBox(height: 20,),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: secondaryColor,
              ),
              onPressed: _register,
              child: Text('Registrate'),
            ),
          ],
        ),
      ),
    );
  }
}
