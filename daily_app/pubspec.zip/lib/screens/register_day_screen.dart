import 'dart:io';
import 'package:daily_app/widgets/select_activities.dart';
import 'package:daily_app/widgets/select_emotions.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';

class RegisterDayScreen extends StatefulWidget {
  const RegisterDayScreen({Key? key}) : super(key: key);

  @override
  State<RegisterDayScreen> createState() => _RegisterDayScreenState();
}

class _RegisterDayScreenState extends State<RegisterDayScreen> {
  String? _name;
  final TextEditingController _textController = TextEditingController();
  bool _isExpanded = false;
  int _characterLimit = 180;
  bool _allowMultipleImages = false;
  List<File?> _selectedImages = [];

  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _loadText();
    _loadImages();
  }

  Future _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _name = prefs.getString('Name');
    });
  }

  Future _saveText() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('dailyText', _textController.text);
  }

  Future _loadText() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _textController.text = prefs.getString('dailyText') ?? '';
    });
  }

  Future _loadImages() async {
    final prefs = await SharedPreferences.getInstance();
    List<String>? savedImages = prefs.getStringList('selectedImages');
    if (savedImages != null) {
      setState(() {
        _selectedImages = savedImages.map((path) => File(path)).toList();
      });
    }
  }

  Future _saveImages() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> imagePaths = _selectedImages.whereType<File>().map((file) => file.path).toList();
    await prefs.setStringList('selectedImages', imagePaths);
  }

  Future<void> _pickImage(ImageSource source) async {
    final pickedFile = await _picker.pickImage(source: source);
    if (pickedFile != null) {
      CroppedFile? croppedFile = await ImageCropper().cropImage(
        sourcePath: pickedFile.path,
        aspectRatio: CropAspectRatio(ratioX: 1, ratioY: 1),
        uiSettings: [AndroidUiSettings(toolbarTitle: 'Recorta tu imagen')],
      );

      if (croppedFile != null) {
        setState(() {
          _allowMultipleImages ? _selectedImages.add(File(croppedFile.path)) : _selectedImages = [File(croppedFile.path)];
        });
        _saveImages();
      }
    }
  }

  void _showImageSourceSelection() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: Icon(Icons.camera),
                title: Text('Tomar una foto'),
                onTap: () {
                  Navigator.of(context).pop();
                  _pickImage(ImageSource.camera);
                },
              ),
              ListTile(
                leading: Icon(Icons.photo_library),
                title: Text('Seleccionar de la galería'),
                onTap: () {
                  Navigator.of(context).pop();
                  _pickImage(ImageSource.gallery);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _toggleCharacterLimit(bool isExpanded) {
    setState(() {
      _isExpanded = isExpanded;
      _characterLimit = _isExpanded ? 500 : 180;
    });
  }

  void _toggleImageCount(bool allowMultiple) {
    setState(() {
      _allowMultipleImages = allowMultiple;
      if (!allowMultiple && _selectedImages.isNotEmpty) {
        _selectedImages = [_selectedImages.first];
      }
      _saveImages();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Registra tu día $_name'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(0.0),
        children: [
          ImageSelector(),
          ActivitiesSelector(title: ('Emociones')),
          ActivitiesSelector(title: ('Personas')),
          ActivitiesSelector(title: ('Lugares')),
          ActivitiesSelector(title: ('Actividades')),
          Padding(
            padding: const EdgeInsets.all(25.0),
            child: TextFormField(
              controller: _textController,
              maxLength: _characterLimit,
              decoration: InputDecoration(
                labelText: 'Describe tu día',
                border: OutlineInputBorder(),
                counterText: '${_textController.text.length}/$_characterLimit caracteres',
              ),
              maxLines: 5,
              onChanged: (text) => _saveText(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25.0),
            child: Row(
              children: [
                Checkbox(
                  value: _isExpanded,
                  onChanged: (value) {
                    if (value != null) _toggleCharacterLimit(value);
                  },
                ),
                Text('Permitir hasta 500 caracteres'),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25.0),
            child: Row(
              children: [
                Checkbox(
                  value: _allowMultipleImages,
                  onChanged: (value) {
                    if (value != null) _toggleImageCount(value);
                  },
                ),
                Text('Permitir hasta 3 imágenes'),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(25.0),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (var image in _selectedImages)
                  if (image != null)
                    Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        image: DecorationImage(
                          image: FileImage(image),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(25.0),
            child: ElevatedButton(
              onPressed: _selectedImages.length < (_allowMultipleImages ? 3 : 1) ? _showImageSourceSelection : null,
              child: Text('Seleccionar Imagen'),
            ),
          ),
        ],
      ),
    );
  }
}
