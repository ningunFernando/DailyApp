import 'package:daily_app/widgets/day_card.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login_screen.dart';
import '../screens/Edit_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? _name;
  String? _lastName;
  String? _phone;
  String? _email;
  String? _password;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  void _loadUserData() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    // Imprimir los valores obtenidos desde SharedPreferences
    print('Datos cargados de SharedPreferences:');
    print('Nombre: ${prefs.getString('Name')}');
    print('Apellido: ${prefs.getString('Lastname')}');
    print('Correo: ${prefs.getString('email')}');
    print('Teléfono: ${prefs.getString('phone')}');

    setState(() {
      _name = prefs.getString('Name');
      _lastName = prefs.getString('Lastname');
      _email = prefs.getString('email');
      _phone = prefs.getString('phone');
      _password = prefs.getString('password');
    });
  }

  Future<void> _navigateAndEditUser(BuildContext context) async {

    final bool? updated = await Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => EditUserScreen()),
    );


    if (updated == true) {
      _loadUserData();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Bienvenido, ${_name ?? 'Usuario'}',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            fontFamily: 'Poppins',
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child:
          ListView(
            children: [
              CustomDayCard( imageNumber: 2,),
              SizedBox(height: 25,),
              CustomDayCard(imageNumber: 1,),
              SizedBox(height: 25,),
              CustomDayCard(imageNumber: 3,),
              SizedBox(height: 25,),
              CustomDayCard(imageNumber: 4,)
            ],
          )
      ),
    );
  }

}
