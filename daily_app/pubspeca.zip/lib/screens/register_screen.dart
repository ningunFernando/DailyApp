import 'dart:convert';
import 'package:flutter/material.dart';
import '../widgets/custom_text_field.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import './navigation_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _emailController = TextEditingController();
  final _confirmEmailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _nameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _phoneController = TextEditingController();

  Future<void> _register() async {
    final url = Uri.parse('https://fertestflutter.guayabitos.site/api/register.php');
    final response = await http.post(url, body: {
      'email': _emailController.text,
      'password': _passwordController.text,
      'name': _nameController.text,
      'lastname': _lastNameController.text,
      'phone': _phoneController.text,
    });

    // Imprimir el estado y cuerpo de la respuesta
    print('Status Code: ${response.statusCode}');
    print('Response Body: ${response.body}');

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);

      if (responseData['status'] == 'success') {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setBool('isLoggedIn', true);
        await prefs.setString('email', _emailController.text);

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => NavigationScreen()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error en el registro: ${responseData['message']}')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error en la conexión: ${response.statusCode}')),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Dai.ly',
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.w700,
            fontFamily: 'Poppins',
          ),
        ),
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 30),
        child: ListView(
          children: [
            Image.asset('images/IconoApp.png', scale: 4),
            CustomTextField(
              labelText: 'Correo',
              prefixIcon: Icons.email_outlined,
              controller: _emailController,
            ),
            SizedBox(height: 10),
            CustomTextField(
              labelText: 'Confirmar Correo',
              prefixIcon: Icons.email_outlined,
              controller: _confirmEmailController,
            ),
            SizedBox(height: 10),
            CustomTextField(
              labelText: 'Contraseña',
              prefixIcon: Icons.lock_outline,
              controller: _passwordController,
              isPassword: true,
            ),
            SizedBox(height: 10),
            CustomTextField(
              labelText: 'Confirmar Contraseña',
              prefixIcon: Icons.lock_outline,
              controller: _confirmPasswordController,
              isPassword: true,
            ),
            SizedBox(height: 10),
            CustomTextField(
              labelText: 'Nombre',
              prefixIcon: Icons.account_circle_outlined,
              controller: _nameController,
            ),
            SizedBox(height: 10),
            CustomTextField(
              labelText: 'Apellido',
              prefixIcon: Icons.account_circle_outlined,
              controller: _lastNameController,
            ),
            SizedBox(height: 10),
            CustomTextField(
              keyboardType: TextInputType.number,
              labelText: 'Teléfono',
              prefixIcon: Icons.phone_android_outlined,
              controller: _phoneController,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue, // Cambia `secondaryColor` por el color que desees
              ),
              onPressed: _register,
              child: Text('Regístrate'),
            ),
          ],
        ),
      ),
    );
  }
}
